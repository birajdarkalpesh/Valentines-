function love() {
    alert("I love you endlessly, Shivani ❤️ – Kalpesh");
}